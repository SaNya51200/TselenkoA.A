"""Модуль с реализациями паттернов проектирования."""

from src.patterns.singleton import DatabaseConnection
from src.patterns.factory_method import (
    EmployeeFactory,
    ManagerFactory,
    DeveloperFactory,
    SalespersonFactory,
    EmployeeFactoryRegistry
)
from src.patterns.strategy import (
    BonusStrategy,
    PerformanceBonusStrategy,
    SeniorityBonusStrategy,
    ProjectBonusStrategy,
    BonusCalculator
)

__all__ = [
    'DatabaseConnection',
    'EmployeeFactory',
    'ManagerFactory',
    'DeveloperFactory',
    'SalespersonFactory',
    'EmployeeFactoryRegistry',
    'BonusStrategy',
    'PerformanceBonusStrategy',
    'SeniorityBonusStrategy',
    'ProjectBonusStrategy',
    'BonusCalculator'
]

