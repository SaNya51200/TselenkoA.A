"""Паттерн Singleton - реэкспорт из database модуля."""

from src.database.connection import DatabaseConnection

__all__ = ['DatabaseConnection']

