"""Модуль для работы с базой данных."""

from src.database.connection import DatabaseConnection

__all__ = ['DatabaseConnection']

